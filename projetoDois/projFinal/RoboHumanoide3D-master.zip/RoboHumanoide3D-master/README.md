# RoboHumanoide3D

Simulação de um robô humanoide em 3D, que caminha pelo plano quadriculado, usando a API Opengl e biblioteca "glut.h". 

Inicialmente ele só faz duas ações: andar (teclando 'A') e parar (teclando 'P'). Mas pode-se acrescentar mais movimentos, como virar para direita, correr, pular, etc.
