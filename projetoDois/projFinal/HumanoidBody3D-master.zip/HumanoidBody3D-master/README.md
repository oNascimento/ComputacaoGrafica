# HumanoidBody3D
An OpenGL humanoid 3D model

This model was made using:
  - C++
  - OpenGL
  - GLUT
  - GLU

![](images/01.PNG)
![](images/02.PNG)
![](images/03.PNG)
![](images/04.PNG)
